import { useMemo, useState } from "react";
import { type Product, categoryLabels, getCategoryColor } from "@/data/products";
import { ShoppingCart, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "@/contexts/CartContext";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addToCart, items } = useCart();
  const [selectedPack, setSelectedPack] = useState(product.packSizes[0]);
  const [added, setAdded] = useState(false);

  // If your cart items have quantity, we’ll use it.
  // If not, we’ll treat each cart line as 1.
  const productCount = useMemo(() => {
    return items
      .filter((i: any) => i.product?.id === product.id)
      .reduce((sum: number, i: any) => sum + (i.quantity ?? 1), 0);
  }, [items, product.id]);

  // OPTIONAL: count per selected pack (only if your cart line stores packSize/pack)
  const selectedPackCount = useMemo(() => {
    return items
      .filter(
        (i: any) =>
          i.product?.id === product.id &&
          (i.packSize === selectedPack || i.pack === selectedPack || i.selectedPack === selectedPack)
      )
      .reduce((sum: number, i: any) => sum + (i.quantity ?? 1), 0);
  }, [items, product.id, selectedPack]);

  const inCart = productCount > 0;

  const handleAdd = () => {
    addToCart(product, selectedPack);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="group rounded-xl border border-border bg-card overflow-hidden card-shadow transition-all duration-300 hover:card-shadow-hover hover:-translate-y-1">
      {/* Image placeholder */}
      <div className="aspect-[4/3] bg-muted relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="mx-auto mb-2 h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-2xl">{product.type === "veg" ? "🥬" : "🍗"}</span>
            </div>
            <p className="text-xs text-muted-foreground">Product Image</p>
          </div>
        </div>
        {/* Category badge */}
        <span
          className={`absolute top-3 left-3 px-2 py-0.5 rounded-full text-[10px] font-semibold ${getCategoryColor(
            product.category
          )}`}
        >
          {categoryLabels[product.category]}
        </span>
        {product.bulkAvailable && (
          <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-primary text-primary-foreground">
            Bulk Available
          </span>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-foreground mb-1 line-clamp-1">{product.name}</h3>
        <p className="text-lg font-bold text-primary mb-2">₹{product.price}</p>

        {/* Pack size selector */}
        <div className="flex flex-wrap gap-1 mb-3">
          {product.packSizes.map((s) => (
            <button
              key={s}
              onClick={() => setSelectedPack(s)}
              className={`text-[10px] px-1.5 py-0.5 rounded font-medium transition-colors ${
                selectedPack === s
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleAdd}
            className={`relative flex-1 flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-all ${
              added
                ? "bg-secondary text-secondary-foreground"
                : "bg-primary text-primary-foreground hover:scale-[1.02]"
            }`}
          >
            {/* Count badge (choose ONE: selectedPackCount or productCount) */}
            {(selectedPackCount > 0 || productCount > 0) && (
              <span className="absolute -top-2 -right-2 min-w-5 h-5 px-1 rounded-full bg-background text-foreground border border-border text-[10px] flex items-center justify-center font-bold">
                {selectedPackCount > 0 ? selectedPackCount : productCount}
              </span>
            )}

            {added ? (
              <>
                <Check className="h-3.5 w-3.5" /> Added!
              </>
            ) : (
              <>
                <ShoppingCart className="h-3.5 w-3.5" /> Add to Cart
              </>
            )}
          </button>

          {inCart && (
            <Link
              to="/cart"
              className="flex items-center justify-center gap-1.5 rounded-lg border border-primary px-3 py-2 text-xs font-semibold text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              Go to Cart
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;