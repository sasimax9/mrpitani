import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Search } from "lucide-react";
import Layout from "@/components/layout/Layout";
import ProductCard from "@/components/ProductCard";
import products, { categoryLabels, type ProductCategory } from "@/data/products";

const vegCategories: ProductCategory[] = ["veg", "general", "veg-snacks"];

const VegProducts = () => {
  const [searchParams] = useSearchParams();
  const initCat = searchParams.get("cat") as ProductCategory | null;
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState<ProductCategory | "all">(
    initCat && vegCategories.includes(initCat) ? initCat : "all"
  );
  const [storageFilter, setStorageFilter] = useState<"all" | "frozen" | "non-frozen">("all");
  const [prepFilter, setPrepFilter] = useState<"all" | "raw" | "ready-to-cook">("all");

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (p.type !== "veg") return false;
      if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (catFilter !== "all" && p.category !== catFilter) return false;
      if (storageFilter !== "all" && p.storage !== storageFilter) return false;
      if (prepFilter !== "all" && p.prep !== prepFilter) return false;
      return true;
    });
  }, [search, catFilter, storageFilter, prepFilter]);

  const FilterBtn = ({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) => (
    <button onClick={onClick} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${active ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>
      {children}
    </button>
  );

  return (
    <Layout>
      <section className="bg-secondary py-12">
        <div className="container">
          <h1 className="text-3xl font-extrabold text-secondary-foreground mb-2">🟢 Veg Products</h1>
          <p className="text-secondary-foreground/80">Fresh & frozen vegetarian products for every kitchen</p>
        </div>
      </section>
      <section className="container py-8">
        <div className="relative mb-6 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input type="text" placeholder="Search veg products..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-xl border border-border bg-card pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div className="flex flex-wrap gap-2 mb-6">
          <FilterBtn active={catFilter === "all"} onClick={() => setCatFilter("all")}>All Veg</FilterBtn>
          {vegCategories.map((cat) => (
            <FilterBtn key={cat} active={catFilter === cat} onClick={() => setCatFilter(cat)}>{categoryLabels[cat]}</FilterBtn>
          ))}
          <span className="w-px bg-border mx-1" />
          <FilterBtn active={storageFilter === "all"} onClick={() => setStorageFilter("all")}>All</FilterBtn>
          <FilterBtn active={storageFilter === "frozen"} onClick={() => setStorageFilter("frozen")}>❄️ Frozen</FilterBtn>
          <FilterBtn active={storageFilter === "non-frozen"} onClick={() => setStorageFilter("non-frozen")}>🌿 Fresh</FilterBtn>
          <span className="w-px bg-border mx-1" />
          <FilterBtn active={prepFilter === "all"} onClick={() => setPrepFilter("all")}>All</FilterBtn>
          <FilterBtn active={prepFilter === "raw"} onClick={() => setPrepFilter("raw")}>Raw</FilterBtn>
          <FilterBtn active={prepFilter === "ready-to-cook"} onClick={() => setPrepFilter("ready-to-cook")}>Ready-to-Cook</FilterBtn>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{filtered.length} products</p>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-16"><p className="text-lg font-semibold text-muted-foreground">No products found</p></div>
        )}
      </section>
    </Layout>
  );
};

export default VegProducts;
